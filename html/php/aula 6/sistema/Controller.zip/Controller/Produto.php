<?php
    class Produto {
        
    }
?>