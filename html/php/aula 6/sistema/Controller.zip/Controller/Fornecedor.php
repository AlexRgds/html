<?php

    class Fornecedor{
        
        
    }

?>