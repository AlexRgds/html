<?php
    class Funcoes{
        public function base64($vlr, $tipo){
            switch($tipo){
                case 1: 
                    $rst = base65_enconde($vlr);break;

                case 2: 
                    $rst = base65_decode($vlr);break;
            }
            return $rst;
        }
        
    }
?>