<?php
    require_once "../vendor/autoload.php";

    $usuario = new Usuario();

    session_start();
    if($_SESSION['logado'] == 'logar'){
        $usuario->deslogarUsuario();

    }
?>