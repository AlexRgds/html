<!DOCTYPE html>
<html lang="en">

    <?php
        require_once "vendor/autoload.php";

        $a = new Cliente();

        $a->imprimeCliente();
