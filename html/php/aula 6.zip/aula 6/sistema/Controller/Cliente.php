<?php
    require_once __DIR__  . "../../vendor/autoload.php";

    class Cliente {
        
        private $id;
        private $cliente;
        private $endereco;
        private $pais;
        private $estado;
        private $cidade;


        /**
         * Get the value of id
         */
        public function getId()
        {
                return $this->id;
        }

        /**
         * Set the value of id
         */
        public function setId($id): self
        {
                $this->id = $id;

                return $this;
        }

        /**
         * Get the value of cliente
         */
        public function getCliente()
        {
                return $this->cliente;
        }

        /**
         * Set the value of cliente
         */
        public function setCliente($cliente): self
        {
                $this->cliente = $cliente;

                return $this;
        }

        /**
         * Get the value of endereco
         */
        public function getEndereco()
        {
                return $this->endereco;
        }

        /**
         * Set the value of endereco
         */
        public function setEndereco($endereco): self
        {
                $this->endereco = $endereco;

                return $this;
        }

        /**
         * Get the value of pais
         */
        public function getPais()
        {
                return $this->pais;
        }

        /**
         * Set the value of pais
         */
        public function setPais($pais): self
        {
                $this->pais = $pais;

                return $this;
        }

        /**
         * Get the value of estado
         */
        public function getEstado()
        {
                return $this->estado;
        }

        /**
         * Set the value of estado
         */
        public function setEstado($estado): self
        {
                $this->estado = $estado;

                return $this;
        }

        /**
         * Get the value of cidade
         */
        public function getCidade()
        {
                return $this->cidade;
        }

        /**
         * Set the value of cidade
         */
        public function setCidade($cidade): self
        {
                $this->cidade = $cidade;

                return $this;
        }

        //Instanciar a Classe de Conexao com o Banco de dados
        public function __construct(){
            $this->con = new Conexao();
            $this->objfn = new Funcoes();
        }

        public function imprimeCliente(){
            echo "Teste de Cliente com Conexa com o Banco de Dados";
        }

        //Gravar no Banco de dados
        public function  inserirCliente($dados) {
            try{
               
                $this->cliente = $dados['cliente'];
                $this->endereco = $dados['endereco'];
                $this->pais = $dados['pais'];
                $this->estado = $dados['estado'];
                $this->cidade = $dados['cidade'];

                if(empty(trim($this->cliente))  ){
                    echo "<html> <div class='alert alert-danger alert-dismissible fade show' role='alert'> Campo cliente em branco <button type='button' class='close' data-dismiss='alert' aria-label='Close'> <span aria-hidden='true'>&times;</span> </button> </div></html>";  
                }else if(empty(trim($this->cliente))  ){
                    echo "<html> <div class='alert alert-danger alert-dismissible fade show' role='alert'> Campo endereço em branco <button type='button' class='close' data-dismiss='alert' aria-label='Close'> <span aria-hidden='true'>&times;</span> </button> </div></html>";  
                } else{

                    $cst = $this->con->conectar()->prepare("INSERT INTO cliente (cliente, endereco, pais, estado, cidade) VALUES(:cliente, :endereco, :pais, :estado, :cidade)");
                    $cst->bindParam(":cliente" , $this->cliente, PDO::PARAM_STR);
                    $cst->bindParam(":endereco" , $this->endereco, PDO::PARAM_STR);
                    $cst->bindParam(":pais" , $this->pais, PDO::PARAM_INT);
                    $cst->bindParam(":estado" , $this->estado, PDO::PARAM_INT);
                    $cst->bindParam(":cidade" , $this->cidade, PDO::PARAM_INT);

                    if($cst->execute()){
                        return 'ok';
                    } else{
                        echo 'Não';
                    }
                }
            }
            catch(PDOException $ex){
                echo $ex;
            }
        }

        //Selecionar do Banco de dados
        public function  selecionarCliente() {
            try{
                $cst = $this->con->conectar()->prepare(
                "SELECT DISTINCT i.id, p.pais, b.estado, c.cidade, i.cliente, i.endereco

                FROM cliente i
               
                join pais p on p.id = i.pais
                join estado b on b.id = i.estado
                join cidade c on c.id = i.cidade
               
                GROUP BY i.id"
                );
                $cst->execute();

                return $cst->fetchAll();

            }catch(PDOException $ex){
                    echo $ex;
            }
        }

        //Seleciona ID do Usuário
        public function selecionaIdentificador($dados) {
            try
            {
                $this->id = $this->objfn->base64($dados, 2);
                $cst = $this->con->conectar()->prepare("SELECT id, cliente FROM cliente WHERE id = :idcliente ");
                $cst->bindParam(":idcliente", $this->id, PDO::PARAM_INT);
                $cst->bindParam(":cliente", $this->cliente, PDO::PARAM_STR);

                $cst->execute();
                return $cst->fetch();
            } catch (PDOException $ex) {
                return 'error '.$ex->getMessage();
            }
        }
        

        //Editar no Banco de dados
        public function  editarCliente($dados) {
            try{

                $this->id = $this->objfn->base64($dados['func'],2);
                $this->nome = $dados['cliente'];
                $this->email = $dados['endereco'];
                $this->pais = $dados['pais'];
                $this->estado = $dados['estado'];
                $this->cidade = $dados['cidade'];

                $cst = $this->con->conectar()->prepare("UPDATE usuario SET cliente = :cliente ,endereco = :endereco ,pais = :pais, estado = :estado, cidade = :cidade WHERE id = :idUser");
                $cst->bindParam(":idUser" , $this->id, PDO::PARAM_INT);
                $cst->bindParam(":cliente" , $this->cliente, PDO::PARAM_STR);
                $cst->bindParam(":endereco" , $this->endereco, PDO::PARAM_STR);
                $cst->bindParam(":pais" , $this->pais, PDO::PARAM_INT);
                $cst->bindParam(":estado" , $this->estado, PDO::PARAM_INT);
                $cst->bindParam(":cidade" , $this->cidade, PDO::PARAM_INT);


                if($cst->execute()){
                    return 'ok';
                } else{
                    echo 'Não';
                }
            }
            catch(PDOException $ex){
                echo $ex;
            }
        }

         //Deletar  no Banco de dados
        public function  deletarCliente($dados) {
            try{
                $this->id = $this->objfn->base64($dados, 2);
    
                $cst = $this->con->conectar()->prepare("DELETE FROM cliente WHERE id= :idUser");
                $cst->bindParam(":idUser" , $this->id, PDO::PARAM_INT);
                    if($cst->execute()){
                        return "ok";
                    } else{
                        return "Não deu";
                    }
                }catch(PDOException $ex){
                    echo $ex;
                }
            }

            public function selecionaEstado()
        {
            try
            {
                $cst = $this->con->conectar()->prepare("SELECT * FROM estado ");
                $cst->execute();

                return $cst->fetchAll();

            }
            catch (PDOException $ex)
            {
                echo $ex;
            }
        }
    }