<ul class="nav justify-content-center">
  <li class="nav-item">
    <a class="nav-link" href="./painel.php">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="./clientes.php">Cadastro cliente</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="./fornecedor.php">Cadastro fornecedor</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="./produto.php">Cadastro produto</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="./email.php">Enviar Email</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="./sair.php">Sair</a>
  </li>
</ul>